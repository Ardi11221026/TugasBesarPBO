public class Main {
    public static void main(String[] args) {
        HalamanLogin.main(new String[0]);
    }
}
