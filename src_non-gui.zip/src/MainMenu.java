
import java.util.Scanner;


public class MainMenu {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        boolean exit = false;

        while (!exit) {
            System.out.println("=== Menu Utama ===");
            System.out.println("1. Data Mobil");
            System.out.println("2. Data Peminjaman");
            System.out.println("3. Data Pengembalian");
            System.out.println("4. Keluar");
            System.out.print("Pilih menu (1-4): ");
            int choice = scanner.nextInt();
            scanner.nextLine(); // Consumes the remaining newline character

            switch (choice) {
                case 1:
                    System.out.println("=== Data Mobil ===");
                    DataMobil.main(new String[0]);
                    break;
                case 2:
                    System.out.println("=== Data Peminjaman ===");
                    DataPeminjaman.main(new String[0]);
                    break;
                case 3:
                    System.out.println("=== Data Pengembalian ===");
                    DataPengembalian.main(new String[0]);
                    break;
                case 4:
                    exit = true;
                    break;
                default:
                    System.out.println("menu tidak tersdia, pilih menu pada daftar");
                    break;
            }
            System.out.println();
        }

        scanner.close();
    }
}
