import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.table.DefaultTableModel;

public class DataPengembalian extends User {
    private DefaultTableModel model;
    private String dataFilePath;
    private Scanner scanner;

    public DataPengembalian() {
        super();
        dataFilePath = "data_pengembalian.txt";
        model = new DefaultTableModel();
        model.addColumn("Nama Peminjam");
        model.addColumn("Nomor Plat");
        model.addColumn("Tanggal Pengembalian");
        model.addColumn("Lama Peminjaman (hari)");
        model.addColumn("Tanggal Peminjaman");
        model.addColumn("Harga");
        scanner = new Scanner(System.in);
    }

    // simpan data
    private void saveDataToFile(String nama, String nomorPlat, String lamaPeminjaman, String tanggalPeminjaman, String harga, String tanggalPengembalian) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFilePath, true))) {
            String data = nama + "," + nomorPlat + "," + lamaPeminjaman + "," + tanggalPeminjaman + "," + harga + "," + tanggalPengembalian;
            writer.write(data);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveDataToTextFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFilePath))) {
            int rowCount = model.getRowCount();
            for (int i = 0; i < rowCount; i++) {
                String nama = model.getValueAt(i, 0).toString();
                String nomorPlat = model.getValueAt(i, 1).toString();
                String lamaPeminjaman = model.getValueAt(i, 2).toString();
                String tanggalPeminjaman = model.getValueAt(i, 3).toString();
                String harga = model.getValueAt(i, 4).toString();
                String tanggalPengembalian = model.getValueAt(i, 5).toString();
                String data = nama + "," + nomorPlat + "," + lamaPeminjaman + "," + tanggalPeminjaman + "," + harga + "," + tanggalPengembalian;
                writer.write(data);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // muat data
    private void loadSavedData() {
        try (BufferedReader reader = new BufferedReader(new FileReader(dataFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                model.addRow(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void inputDataPengembalian() {
        System.out.print("Nama Peminjam: ");
        String nama = scanner.nextLine();
        System.out.print("Nomor Plat: ");
        String nomorPlat = scanner.nextLine();
        System.out.print("Lama Peminjaman (dalam hari): ");
        String lamaPeminjaman = scanner.nextLine();
        System.out.print("Tanggal Peminjaman: ");
        String tanggalPeminjaman = scanner.nextLine();
        System.out.print("Harga: ");
        String harga = scanner.nextLine();
        System.out.print("Tanggal Pengembalian: ");
        String tanggalPengembalian = scanner.nextLine();

        model.addRow(new Object[]{nama, nomorPlat, lamaPeminjaman, tanggalPeminjaman, harga, tanggalPengembalian});
        saveDataToFile(nama, nomorPlat, lamaPeminjaman, tanggalPeminjaman, harga, tanggalPengembalian);
    }

    public void deleteDataPengembalian(int row) {
        if (row >= 0) {
            model.removeRow(row);
            saveDataToTextFile();
        } else {
            System.out.println("Pilih baris data yang ingin dihapus.");
        }
    }

    public void displayDataPengembalian() {
        System.out.println("Data Pengembalian:");
        int rowCount = model.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            String nama = model.getValueAt(i, 0).toString();
            String nomorPlat = model.getValueAt(i, 1).toString();
            String lamaPeminjaman = model.getValueAt(i, 2).toString();
            String tanggalPeminjaman = model.getValueAt(i, 3).toString();
            String harga = model.getValueAt(i, 4).toString();
            String tanggalPengembalian = model.getValueAt(i, 5).toString();
            System.out.println("Nama Peminjam: " + nama);
            System.out.println("Nomor Plat: " + nomorPlat);
            System.out.println("Lama Peminjaman (hari): " + lamaPeminjaman);
            System.out.println("Tanggal Peminjaman: " + tanggalPeminjaman);
            System.out.println("Harga: " + harga);
            System.out.println("Tanggal Pengembalian: " + tanggalPengembalian);
            System.out.println("----------------------------------");
        }
    }

    public static void main(String[] args) {
        DataPengembalian dataPengembalian = new DataPengembalian();
        dataPengembalian.loadSavedData();

        boolean isRunning = true;
        while (isRunning) {
            System.out.println("Menu:");
            System.out.println("1. Input Data Pengembalian");
            System.out.println("2. Hapus Data Pengembalian");
            System.out.println("3. Tampilkan Data Pengembalian");
            System.out.println("4. Keluar");
            System.out.print("Pilih menu (1-4): ");
            int choice = dataPengembalian.scanner.nextInt();
            dataPengembalian.scanner.nextLine();

            switch (choice) {
                case 1:
                    dataPengembalian.inputDataPengembalian();
                    break;
                case 2:
                    System.out.print("Pilih baris data yang ingin dihapus: ");
                    int row = dataPengembalian.scanner.nextInt();
                    dataPengembalian.scanner.nextLine();
                    dataPengembalian.deleteDataPengembalian(row);
                    break;
                case 3:
                    dataPengembalian.displayDataPengembalian();
                    break;
                case 4:
                    isRunning = false;
                    System.out.println("Terima kasih!");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan pilih menu (1-4).");
            }
        }
    }
}
