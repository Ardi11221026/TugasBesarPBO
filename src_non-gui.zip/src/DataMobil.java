import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.table.DefaultTableModel;

public class DataMobil extends Mobil {
    private DefaultTableModel model;
    private String dataFilePath;
    private Scanner scanner;

    public DataMobil() {
        super();
        dataFilePath = "data_mobil.txt";
        model = new DefaultTableModel();
        model.addColumn("Merk Mobil");
        model.addColumn("Nomor Plat");
        model.addColumn("Tahun");
        model.addColumn("Harga");
        scanner = new Scanner(System.in);
    }

    // simpan data
    private void saveDataToFile(String merk, String nomorPlat, String tahun, String harga) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFilePath, true))) {
            String data = merk + "," + nomorPlat + "," + tahun + "," + harga;
            writer.write(data);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveDataToTextFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFilePath))) {
            int rowCount = model.getRowCount();
            for (int i = 0; i < rowCount; i++) {
                String merk = model.getValueAt(i, 0).toString();
                String nomorPlat = model.getValueAt(i, 1).toString();
                String tahun = model.getValueAt(i, 2).toString();
                String harga = model.getValueAt(i, 3).toString();
                String data = merk + "," + nomorPlat + "," + tahun + "," + harga;
                writer.write(data);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // muat data
    private void loadSavedData() {
        try (BufferedReader reader = new BufferedReader(new FileReader(dataFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                model.addRow(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void inputDataMobil() {
        System.out.print("Merk Mobil: ");
        String merk = scanner.nextLine();
        System.out.print("Nomor Plat: ");
        String nomorPlat = scanner.nextLine();
        System.out.print("Tahun: ");
        String tahun = scanner.nextLine();
        System.out.print("Harga: ");
        String harga = scanner.nextLine();
        
        model.addRow(new Object[]{merk, nomorPlat, tahun, harga});
        saveDataToFile(merk, nomorPlat, tahun, harga);
    }

    public void deleteDataMobil(int row) {
        if (row >= 0) {
            model.removeRow(row);
            saveDataToTextFile();
        } else {
            System.out.println("Pilih baris data yang ingin dihapus.");
        }
    }

    public void displayDataMobil() {
        System.out.println("Data Mobil:");
        int rowCount = model.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            String merk = model.getValueAt(i, 0).toString();
            String nomorPlat = model.getValueAt(i, 1).toString();
            String tahun = model.getValueAt(i, 2).toString();
            String harga = model.getValueAt(i, 3).toString();
            System.out.println("Merk Mobil: " + merk);
            System.out.println("Nomor Plat: " + nomorPlat);
            System.out.println("Tahun Produksi: " + tahun);
            System.out.println("Harga: " + harga);
            System.out.println("----------------------------------");
        }
    }

    public static void main(String[] args) {
        DataMobil dataMobil = new DataMobil();
        dataMobil.loadSavedData();

        boolean isRunning = true;
        while (isRunning) {
            System.out.println("Menu:");
            System.out.println("1. Input Data Mobil");
            System.out.println("2. Hapus Data Mobil");
            System.out.println("3. Tampilkan Data Mobil");
            System.out.println("4. Keluar");
            System.out.print("Pilih menu (1-4): ");
            int choice = dataMobil.scanner.nextInt();
            dataMobil.scanner.nextLine();

            switch (choice) {
                case 1:
                    dataMobil.inputDataMobil();
                    break;
                case 2:
                    System.out.print("Pilih baris data yang ingin dihapus: ");
                    int row = dataMobil.scanner.nextInt();
                    dataMobil.scanner.nextLine();
                    dataMobil.deleteDataMobil(row);
                    break;
                case 3:
                    dataMobil.displayDataMobil();
                    break;
                case 4:
                    isRunning = false;
                    System.out.println("Terima kasih!");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan pilih menu (1-4).");
            }
        }
    }
}
