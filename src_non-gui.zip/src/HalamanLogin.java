import java.util.Scanner;

public class HalamanLogin {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        String username, password;

        System.out.println("=== Halaman Login ===");

        System.out.print("Username: ");
        username = scanner.nextLine();

        System.out.print("Password: ");
        password = scanner.nextLine();

        if (validateLogin(username, password)) {
            System.out.println("Login berhasil!");
            System.out.println("Selamat datang, " + username + "!");
            System.out.println();

            MainMenu.main(new String[0]);
        } else {
            System.out.println("Username atau Kata sandi salah!");
        }
    }

    private static boolean validateLogin(String username, String password) {
        return username.equals("admin") && password.equals("admin");
    }
}
