import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.Scanner;

import javax.swing.table.DefaultTableModel;

public class DataPeminjaman extends User {
    private DefaultTableModel model;
    private String dataFilePath;
    private Scanner scanner;

    public DataPeminjaman() {
        super();
        dataFilePath = "data_peminjaman.txt";
        model = new DefaultTableModel();
        model.addColumn("Nama Peminjam");
        model.addColumn("No. Telepon");
        model.addColumn("Email");
        model.addColumn("Alamat");
        model.addColumn("Nomor Plat");
        model.addColumn("Lama Peminjaman");
        model.addColumn("Tanggal Peminjaman");
        model.addColumn("Harga");
        scanner = new Scanner(System.in);
    }

    // simpan data
    private void saveDataToFile(String nama, String noTelepon, String email, String alamat, String nomorPlat, String lamaPeminjaman, String tanggalPeminjaman, String harga) {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFilePath, true))) {
            String data = nama + "," + noTelepon + "," + email + "," + alamat + "," + nomorPlat + "," + lamaPeminjaman + "," + tanggalPeminjaman + "," + harga;
            writer.write(data);
            writer.newLine();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void saveDataToTextFile() {
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(dataFilePath))) {
            int rowCount = model.getRowCount();
            for (int i = 0; i < rowCount; i++) {
                String nama = model.getValueAt(i, 0).toString();
                String noTelepon = model.getValueAt(i, 1).toString();
                String email = model.getValueAt(i, 2).toString();
                String alamat = model.getValueAt(i, 3).toString();
                String nomorPlat = model.getValueAt(i, 4).toString();
                String lamaPeminjaman = model.getValueAt(i, 5).toString();
                String tanggalPeminjaman = model.getValueAt(i, 6).toString();
                String harga = model.getValueAt(i, 7).toString();
                String data = nama + "," + noTelepon + "," + email + "," + alamat + "," + nomorPlat + "," + lamaPeminjaman + "," + tanggalPeminjaman + "," + harga;
                writer.write(data);
                writer.newLine();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    // muat data
    private void loadSavedData() {
        try (BufferedReader reader = new BufferedReader(new FileReader(dataFilePath))) {
            String line;
            while ((line = reader.readLine()) != null) {
                String[] data = line.split(",");
                model.addRow(data);
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void inputDataPeminjaman() {
        System.out.print("Nama Peminjam: ");
        String nama = scanner.nextLine();
        System.out.print("No. Telepon: ");
        String noTelepon = scanner.nextLine();
        System.out.print("Email: ");
        String email = scanner.nextLine();
        System.out.print("Alamat: ");
        String alamat = scanner.nextLine();
        System.out.print("Nomor Plat: ");
        String nomorPlat = scanner.nextLine();
        System.out.print("Lama Peminjaman (dalam hari): ");
        String lamaPeminjaman = scanner.nextLine();
        System.out.print("Tanggal Peminjaman: ");
        String tanggalPeminjaman = scanner.nextLine();
        System.out.print("Harga: ");
        String harga = scanner.nextLine();

        model.addRow(new Object[]{nama, noTelepon, email, alamat, nomorPlat, lamaPeminjaman, tanggalPeminjaman, harga});
        saveDataToFile(nama, noTelepon, email, alamat, nomorPlat, lamaPeminjaman, tanggalPeminjaman, harga);
    }

    public void deleteDataPeminjaman(int row) {
        if (row >= 0) {
            model.removeRow(row);
            saveDataToTextFile();
        } else {
            System.out.println("Pilih baris data yang ingin dihapus.");
        }
    }

    public void displayDataPeminjaman() {
        System.out.println("Data Peminjaman:");
        int rowCount = model.getRowCount();
        for (int i = 0; i < rowCount; i++) {
            String nama = model.getValueAt(i, 0).toString();
            String noTelepon = model.getValueAt(i, 1).toString();
            String email = model.getValueAt(i, 2).toString();
            String alamat = model.getValueAt(i, 3).toString();
            String nomorPlat = model.getValueAt(i, 4).toString();
            String lamaPeminjaman = model.getValueAt(i, 5).toString();
            String tanggalPeminjaman = model.getValueAt(i, 6).toString();
            String harga = model.getValueAt(i, 7).toString();
            System.out.println("Nama Peminjam: " + nama);
            System.out.println("No. Telepon: " + noTelepon);
            System.out.println("Email: " + email);
            System.out.println("Alamat: " + alamat);
            System.out.println("Nomor Plat: " + nomorPlat);
            System.out.println("Lama Peminjaman: " + lamaPeminjaman);
            System.out.println("Tanggal Peminjaman: " + tanggalPeminjaman);
            System.out.println("Harga: " + harga);
            System.out.println("----------------------------------");
        }
    }

    public static void main(String[] args) {
        DataPeminjaman dataPeminjaman = new DataPeminjaman();
        dataPeminjaman.loadSavedData();

        boolean isRunning = true;
        while (isRunning) {
            System.out.println("Menu:");
            System.out.println("1. Input Data Peminjaman");
            System.out.println("2. Hapus Data Peminjaman");
            System.out.println("3. Tampilkan Data Peminjaman");
            System.out.println("4. Keluar");
            System.out.print("Pilih menu (1-4): ");
            int choice = dataPeminjaman.scanner.nextInt();
            dataPeminjaman.scanner.nextLine();

            switch (choice) {
                case 1:
                    dataPeminjaman.inputDataPeminjaman();
                    break;
                case 2:
                    System.out.print("Pilih baris data yang ingin dihapus: ");
                    int row = dataPeminjaman.scanner.nextInt();
                    dataPeminjaman.scanner.nextLine();
                    dataPeminjaman.deleteDataPeminjaman(row);
                    break;
                case 3:
                    dataPeminjaman.displayDataPeminjaman();
                    break;
                case 4:
                    isRunning = false;
                    System.out.println("Terima kasih!");
                    break;
                default:
                    System.out.println("Pilihan tidak valid. Silakan pilih menu (1-4).");
            }
        }
    }
}
