# oop-final-project: Pendataan Rental Mobil
Final project repo for my java OOP subject
Final Project Pemrograman Berbasis Objek
------------------------------------------

Made with Java and Java Swing GUI

